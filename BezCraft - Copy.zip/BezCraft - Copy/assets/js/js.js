document.addEventListener('DOMContentLoaded', function () {
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  tooltipTriggerList.forEach((tooltipTriggerEl) => {
    new bootstrap.Tooltip(tooltipTriggerEl);
  });
});

function animateCountUp(el, target, step = 100, duration = 2000) {
  let current = 0;
  const element = document.getElementById(el);
  const totalSteps = Math.ceil(target / step);
  const stepTime = Math.max(Math.floor(duration / totalSteps), 20); // سرعت

  const timer = setInterval(() => {
    current += step;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    element.textContent = `${current}h`;
  }, stepTime);
}

window.addEventListener("DOMContentLoaded", () => {
  animateCountUp("playtime", 6942, 121, 2500); // شمارش تا 6942 با گام 100، در 2 ثانیه
});

// --------for clan-------- \\
function animateToElevenSmooth(el) {
  const element = document.getElementById(el);
  const finalNumber = 11;
  const numbers = [...Array(finalNumber).keys()].map(n => n + 1); // [1,2,...,11]
  
  // زمان‌های مختلف برای هر عدد (عددهای پایانی کندتر)
  const delays = [50, 60, 70, 90, 110, 130, 160, 200, 300, 400]; // برای 1 تا 10
  let totalDelay = 0;

  numbers.slice(0, 10).forEach((num, index) => {
    totalDelay += delays[index];
    setTimeout(() => {
      element.textContent = `${num}`;
    }, totalDelay);
  });

  // بعد از مکث 1.5s عدد 11 رو نشون بده
  totalDelay += 1500;
  setTimeout(() => {
    element.textContent = `${finalNumber}`;
  }, totalDelay);
}

window.addEventListener("DOMContentLoaded", () => {
  animateToElevenSmooth("playtime-eleven");
});